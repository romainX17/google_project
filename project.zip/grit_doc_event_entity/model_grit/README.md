## single transformer enc-dec model (GRIT)

### Train and Test
Run `bash run_pl.sh`. 

Pass `--n_gpu` flag to change the number of GPUs (Default uses 1).

### only Test
comment `--do_train` and Run `bash run_pl.sh`.
